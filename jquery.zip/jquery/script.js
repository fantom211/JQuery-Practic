$('#block').css({
    'background-color':'red', width:'200px', height:'200px'
})